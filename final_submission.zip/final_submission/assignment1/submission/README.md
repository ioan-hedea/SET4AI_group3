# Running both groups cross tests 

To run group1's tests on group2's model and vice versa, run the cross_test_models.ipynb notebook